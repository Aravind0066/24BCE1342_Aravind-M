const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const memberRoutes = require("./routes/memberRoutes");
const trainerRoutes = require("./routes/trainerRoutes");
const membershipPlanRoutes = require("./routes/membershipPlanRoutes");
const workoutProgramRoutes = require("./routes/workoutProgramRoutes");
const enrollmentRoutes = require("./routes/enrollmentRoutes");
const path = require("path");



dotenv.config();

connectDB();

const app = express();

app.use(express.json());

app.use("/members", memberRoutes);
app.use("/trainers", trainerRoutes);
app.use("/plans", membershipPlanRoutes);
app.use("/programs", workoutProgramRoutes);
app.use("/enrollments", enrollmentRoutes);

app.use(express.static(path.join(__dirname, "public")));


app.get("/", (req, res) => {
    res.sendFile(
        path.join(__dirname,
        "public",
        "index.html")
    );
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});