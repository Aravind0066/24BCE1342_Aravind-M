const mongoose = require("mongoose");

const enrollmentSchema = new mongoose.Schema({

  memberId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Member",
    required: true
  },

  planId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "MembershipPlan",
    required: true
  },

  programId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "WorkoutProgram",
    required: true
  },

  enrollmentDate: {
    type: Date,
    default: Date.now
  }

});

module.exports = mongoose.model(
  "Enrollment",
  enrollmentSchema
);