const mongoose = require("mongoose");

const membershipPlanSchema = new mongoose.Schema({
  planName: {
    type: String,
    required: true
  },

  duration: {
    type: Number,
    required: true
  },

  price: {
    type: Number,
    required: true
  }
});

module.exports = mongoose.model(
  "MembershipPlan",
  membershipPlanSchema
);