const express = require("express");
const router = express.Router();

const WorkoutProgram = require("../models/WorkoutProgram");

router.post("/", async (req, res) => {
  try {
    const program = await WorkoutProgram.create(req.body);
    res.status(201).json(program);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get("/", async (req, res) => {
  try {

    const programs =
      await WorkoutProgram.find()
      .populate("trainerId");

    res.status(200).json(programs);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});

router.put("/:id", async (req, res) => {
  try {
    const program = await WorkoutProgram.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    res.status(200).json(program);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    await WorkoutProgram.findByIdAndDelete(req.params.id);

    res.status(200).json({
      message: "Program deleted successfully"
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;