const mongoose = require("mongoose");

const workoutProgramSchema = new mongoose.Schema({
  programName: {
    type: String,
    required: true
  },

  duration: {
    type: Number,
    required: true
  },

  trainerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Trainer",
    required: true
  }
});

module.exports = mongoose.model(
  "WorkoutProgram",
  workoutProgramSchema
);