const express = require("express");
const router = express.Router();

const Enrollment = require("../models/Enrollment");


router.post("/", async (req, res) => {
  try {

    const enrollment =
      await Enrollment.create(req.body);

    res.status(201).json(enrollment);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});


// GET ALL ENROLLMENTS
router.get("/", async (req, res) => {
  try {

    const enrollments =
      await Enrollment.find()
        .populate("memberId")
        .populate("planId")
        .populate("programId");

    res.status(200).json(enrollments);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});


router.get("/:id", async (req, res) => {
  try {

    const enrollment =
      await Enrollment.findById(req.params.id)
        .populate("memberId")
        .populate("planId")
        .populate("programId");

    if (!enrollment) {
      return res.status(404).json({
        message: "Enrollment not found"
      });
    }

    res.status(200).json(enrollment);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});


router.put("/:id", async (req, res) => {
  try {

    const enrollment =
      await Enrollment.findByIdAndUpdate(
        req.params.id,
        req.body,
        {
          new: true,
          runValidators: true
        }
      )
      .populate("memberId")
      .populate("planId")
      .populate("programId");

    if (!enrollment) {
      return res.status(404).json({
        message: "Enrollment not found"
      });
    }

    res.status(200).json(enrollment);

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});


router.delete("/:id", async (req, res) => {
  try {

    const enrollment =
      await Enrollment.findByIdAndDelete(
        req.params.id
      );

    if (!enrollment) {
      return res.status(404).json({
        message: "Enrollment not found"
      });
    }

    res.status(200).json({
      message: "Enrollment deleted successfully"
    });

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
});

module.exports = router;