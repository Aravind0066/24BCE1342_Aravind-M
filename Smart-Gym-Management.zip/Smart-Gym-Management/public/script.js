
function createRecordCard(title, content) {
    return `
    <div class="record-card">
        <h3>${title}</h3>
        ${content}
    </div>
    `;
}

async function loadModule(type){

    let section;

    let data = [];

    if(type==="member"){

        section =
        document.getElementById(
        "memberSection"
        );

        section.style.display =
        "block";

        section.scrollIntoView({
            behavior:"smooth"
        });

        data = await fetch("/members")
        .then(res=>res.json());

        section.innerHTML = `

        <div class="feature module-section"
            style="max-width:1200px;margin:auto;">

            <button
            class="close-btn"
            onclick="
            document.getElementById(
            'memberSection'
            ).style.display='none'
            ">

            ✕

            </button>

            <h2>Members</h2>

            <br>

            <div id="recordList">

                ${
                    data.map(member =>

                    createRecordCard(

                    member.name,

                    `
                    <p><strong>Email:</strong> ${member.email}</p>
                    <p><strong>Phone:</strong> ${member.phone}</p>
                    <p><strong>Age:</strong> ${member.age}</p>
                    <p><strong>ID:</strong> ${member._id}</p>

                    <button
                    class="delete-btn"
                    onclick="deleteMember('${member._id}')">

                    Delete

                    </button>
                    `

                    )

                    ).join("")
                }

            </div>

            <hr style="margin:30px 0;">

            <h2>Add Member</h2>

            <br>

            <input id="memberName" placeholder="Name">

            <br><br>

            <input id="memberEmail" placeholder="Email">

            <br><br>

            <input id="memberPhone" placeholder="Phone">

            <br><br>

            <input id="memberAge" placeholder="Age">

            <br><br>

            <button onclick="addMember()">
                Add Member
            </button>

        </div>

        `;
    }

    if(type==="trainer"){

        section =
        document.getElementById(
        "trainerSection"
        );

        section.style.display =
        "block";

        section.scrollIntoView({
            behavior:"smooth"
        });
        data = await fetch("/trainers")
        .then(res=>res.json());

        section.innerHTML = `

        <div class="feature module-section"
            style="max-width:1200px;margin:auto;">

            <button
            class="close-btn"
            onclick="
            document.getElementById(
            'trainerSection'
            ).style.display='none'
            ">

            ✕

            </button>

            <h2>Trainers</h2>

            <br>

            <div id="recordList">

                ${
                    data.map(trainer =>

                    createRecordCard(

                    trainer.name,

                    `
                    <p><strong>Specialization:</strong> ${trainer.specialization}</p>
                    <p><strong>Experience:</strong> ${trainer.experience} Years</p>
                    <p><strong>ID:</strong> ${trainer._id}</p>

                    <button
                    class="delete-btn"
                    onclick="deleteTrainer('${trainer._id}')">

                    Delete

                    </button>
                    `

                    )

                    ).join("")
                }

            </div>

            <hr style="margin:30px 0;">

            <h2>Add Trainer</h2>

            <br>

            <input id="trainerName"
                   placeholder="Name">

            <br><br>

            <input id="trainerSpecialization"
                   placeholder="Specialization">

            <br><br>

            <input id="trainerExperience"
                   placeholder="Experience in Years">

            <br><br>

            <button onclick="addTrainer()">
                Add Trainer
            </button>

        </div>

        `;
    }

    if(type==="plan"){

        section =
        document.getElementById(
        "planSection"
        );

        section.style.display =
        "block";

        section.scrollIntoView({
            behavior:"smooth"
        });
        data = await fetch("/plans")
        .then(res=>res.json());

        section.innerHTML = `

        <div class="feature module-section"
            style="max-width:1200px;margin:auto;">

            <button
            class="close-btn"
            onclick="
            document.getElementById(
            'planSection'
            ).style.display='none'
            ">

            ✕

            </button>

            <h2>Membership Plans</h2>

            <br>

            <div id="recordList">

                ${
                    data.map(plan =>

                    createRecordCard(

                    plan.planName,

                    `
                    <p><strong>Duration:</strong> ${plan.duration} Months</p>
                    <p><strong>Price:</strong> ₹${plan.price}</p>
                    <p><strong>ID:</strong> ${plan._id}</p>

                    <br>

                    <button
                    class="delete-btn"
                    onclick="deletePlan('${plan._id}')">

                    Delete

                    </button>
                    `

                    )

                    ).join("")
                }

            </div>

            <hr style="margin:30px 0;">

            <h2>Add Membership Plan</h2>

            <br>

            <input id="planName"
                   placeholder="Plan Name">

            <br><br>

            <input id="planDuration"
                   placeholder="Duration (Months)">

            <br><br>

            <input id="planPrice"
                   placeholder="Price">

            <br><br>

            <button onclick="addPlan()">
                Add Plan
            </button>

        </div>

        `;
    }

    if(type==="program"){

        section =
        document.getElementById(
        "programSection"
        );

        section.style.display =
        "block";

        section.scrollIntoView({
            behavior:"smooth"
        });

        const trainers =
        await fetch("/trainers")
        .then(res=>res.json());

        data = await fetch("/programs")
        .then(res=>res.json());

        section.innerHTML = `

        <div class="feature module-section"
            style="max-width:1200px;margin:auto;">

            <button
            class="close-btn"
            onclick="
            document.getElementById(
            'programSection'
            ).style.display='none'
            ">

            ✕

            </button>

            <h2>Workout Programs</h2>

            <br>

            <div id="recordList">

                ${
                    data.map(program =>

                    createRecordCard(

                    program.programName,

                    `
                    <p>
                        <strong>Duration:</strong>
                        ${program.duration} Days
                    </p>

                    <p>
                        <strong>Trainer:</strong>
                        ${program.trainerId?.name || "Unknown Trainer"}
                    </p>

                    <p>
                        <strong>Specialization:</strong>
                        ${program.trainerId?.specialization || "N/A"}
                    </p>

                    <p>
                        <strong>Experience:</strong>
                        ${program.trainerId?.experience || 0} Years
                    </p>

                    <p>
                        <strong>Program ID:</strong>
                        ${program._id}
                    </p>

                    <br>

                    <button
                    class="delete-btn"
                    onclick="deleteProgram('${program._id}')">

                    Delete

                    </button>
                    `

                    )

                    ).join("")
                }

            </div>

            <hr style="margin:30px 0;">

            <h2>Add Workout Program</h2>

            <br>

            <input id="programName"
                placeholder="Program Name">

            <br><br>

            <input id="programDuration"
                placeholder="Duration (Days)">

            <br><br>

            <select id="trainerId">

            ${

            trainers.map(trainer =>

            `

            <option value="${trainer._id}">
                ${trainer.name}
            </option>

            `

            ).join("")

            }

            </select>

            <br><br>

            <button onclick="addProgram()">
                Add Program
            </button>

        </div>

        `;
    }

    if(type==="enroll"){

        section =
        document.getElementById(
        "enrollmentSection"
        );

        section.style.display =
        "block";

        section.scrollIntoView({
            behavior:"smooth"
        });

        const enrollments =
        await fetch("/enrollments")
        .then(res=>res.json());

        const members =
        await fetch("/members")
        .then(res=>res.json());

        const plans =
        await fetch("/plans")
        .then(res=>res.json());

        const programs =
        await fetch("/programs")
        .then(res=>res.json());

        section.innerHTML = `

        <div class="feature module-section"
            style="max-width:1200px;margin:auto;">

            <button
            class="close-btn"
            onclick="
            document.getElementById(
            'enrollmentSection'
            ).style.display='none'
            ">

            ✕

            </button>

            <h2>Current Enrollments</h2>

            <br>

            <div id="recordList">

            ${

            enrollments.map(enrollment =>

            createRecordCard(

            enrollment.memberId?.name || "Unknown Member",

            `

            <p>
            <strong>Plan:</strong>
            ${enrollment.planId?.planName || "Unknown Plan"}
            </p>

            <p>
            <strong>Program:</strong>
            ${enrollment.programId?.programName || "Unknown Program"}
            </p>

            <p>
            <strong>Date:</strong>
            ${new Date(
            enrollment.enrollmentDate
            ).toLocaleDateString()}
            </p>

            <br>

            <button
            class="delete-btn"
            onclick="deleteEnrollment('${enrollment._id}')">

            Delete

            </button>

            `

            )

            ).join("")

            }

            </div>

            <hr style="margin:30px 0;">

            <h2>Create Enrollment</h2>

            <br>

            <label>Member</label>

            <br><br>

            <select id="memberId">

                ${
                    members.map(member =>

                    `<option value="${member._id}">
                        ${member.name}
                    </option>`

                    ).join("")
                }

            </select>

            <br><br>

            <label>Membership Plan</label>

            <br><br>

            <select id="planId">

                ${
                    plans.map(plan =>

                    `<option value="${plan._id}">
                        ${plan.planName}
                        (₹${plan.price})
                    </option>`

                    ).join("")
                }

            </select>

            <br><br>

            <label>Workout Program</label>

            <br><br>

            <select id="programId">

                ${
                    programs.map(program =>

                    `<option value="${program._id}">
                        ${program.programName}
                    </option>`

                    ).join("")
                }

            </select>

            <br><br>

            <button onclick="addEnrollment()">
                Enroll Member
            </button>

        </div>

        `;
    }

}

async function addMember(){

    const member = {

        name:
        document.getElementById("memberName").value,

        email:
        document.getElementById("memberEmail").value,

        phone:
        document.getElementById("memberPhone").value,

        age:
        Number(
          document.getElementById("memberAge").value
        )

    };

    const response =
    await fetch("/members",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(member)

    });

    if(response.ok){

        alert("Member Added Successfully");

        loadModule("member");

    }
}

async function addTrainer(){

    const trainer = {

        name:
        document.getElementById("trainerName").value,

        specialization:
        document.getElementById(
        "trainerSpecialization"
        ).value,

        experience:
        Number(
        document.getElementById(
        "trainerExperience"
        ).value
        )

    };

    const response =
    await fetch("/trainers",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(trainer)

    });

    if(response.ok){

        alert("Trainer Added Successfully");

        loadModule("trainer");

    }
}

async function addPlan(){

    const plan = {

        planName:
        document.getElementById("planName").value,

        duration:
        Number(
        document.getElementById(
        "planDuration"
        ).value
        ),

        price:
        Number(
        document.getElementById(
        "planPrice"
        ).value
        )

    };

    const response =
    await fetch("/plans",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(plan)

    });

    if(response.ok){

        alert("Plan Added Successfully");

        loadModule("plan");

    }
}



async function addProgram(){

    const program = {

        programName:
        document.getElementById(
        "programName"
        ).value,

        duration:
        Number(
        document.getElementById(
        "programDuration"
        ).value
        ),

        trainerId:
        document.getElementById(
        "trainerId"
        ).value

    };

    const response =
    await fetch("/programs",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(program)

    });

    if(response.ok){

        alert("Program Added Successfully");

        loadModule("program");

    }
}

async function addEnrollment(){

    const enrollment = {

        memberId:
        document.getElementById("memberId").value,

        planId:
        document.getElementById("planId").value,

        programId:
        document.getElementById("programId").value

    };

    const response =
    await fetch("/enrollments",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(enrollment)

    });

    if(response.ok){

        alert("Enrollment Created Successfully");

        loadModule("enroll");

    }

}


async function deleteMember(id){

    const confirmed =
    confirm(
        "Delete this member?"
    );

    if(!confirmed){
        return;
    }

    await fetch(
        `/members/${id}`,
        {
            method:"DELETE"
        }
    );

    loadModule("member");
}

async function deleteTrainer(id){
    
    const confirmed =
    confirm(
        "Delete this trainer?"
    );

    if(!confirmed){
        return;
    }

    await fetch(
        `/trainers/${id}`,
        {
            method:"DELETE"
        }
    );

    loadModule("trainer");
}

async function deletePlan(id){

    const confirmed =
    confirm(
        "Delete this membership plan?"
    );

    if(!confirmed){
        return;
    }

    await fetch(
        `/plans/${id}`,
        {
            method:"DELETE"
        }
    );

    loadModule("plan");
}

async function deleteProgram(id){

    const confirmed =
    confirm(
        "Delete this workout program?"
    );

    if(!confirmed){
        return;
    }

    await fetch(
        `/programs/${id}`,
        {
            method:"DELETE"
        }
    );

    loadModule("program");
}

async function deleteEnrollment(id){

    const confirmed =
    confirm(
        "Delete this enrollment?"
    );

    if(!confirmed){
        return;
    }

    await fetch(
        `/enrollments/${id}`,
        {
            method:"DELETE"
        }
    );

    loadModule("enroll");
}

const reveals =
document.querySelectorAll(".reveal");

function revealElements(){

  reveals.forEach((element)=>{

    const top =
    element.getBoundingClientRect().top;

    if(top < window.innerHeight - 100){

      element.classList.add("active");

    }

  });

}

window.addEventListener(
  "scroll",
  revealElements
);

revealElements();


